package com.s464968.gamedata.item;

public enum ItemType {
    HELM,ARMOR,BOOTS,WEAPON
}
