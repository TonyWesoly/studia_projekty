package com.s464968.gamedata.monster.monsterComponents;

import com.s464968.gamedata.Player;

public abstract class LossComponent {
    public abstract void use(Player player);
}
