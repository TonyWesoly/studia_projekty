package com.s464968.gamedata.monster.monsterObjects;

import com.s464968.gamedata.monster.MonsterData;

public class Cyberbug extends MonstersGen{
    public Cyberbug(){
        monsterData = new MonsterData(
                "Cyberbug 77",
                "Personal responsibility...",
                "Próbuję coś zrobić ale się zawiesza. Nic sie nie dzieje",
                14,
                2
        );
    }
}
